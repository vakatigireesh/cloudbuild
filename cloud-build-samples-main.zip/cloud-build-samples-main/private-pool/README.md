# private-pools-sample
Code example used in "Accessing resources in a private network with private pools"
https://cloud.google.com/build/docs/private-pools/access-resources-in-private-network
