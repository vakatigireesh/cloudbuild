# deploy-firebase-example
Code example used in [Deploying to Firebase](https://cloud.google.com/cloud-build/docs/deploying-builds/deploy-firebase) user guide. For instructions on running this code sample, see the user guide.
