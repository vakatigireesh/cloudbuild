# basic-config-example
Code example used in "Creating a basic build configuration file"
https://cloud.google.com/build/docs/configuring-builds/create-basic-configuration
